"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, MapPin, Filter, Users, MessageCircle } from "lucide-react"
import Link from "next/link"

interface SearchResult {
  id: string
  display_name: string
  bio: string
  location: string
  profile_image_url: string
  skills: Array<{
    name: string
    category: string
    proficiency_level: string
    years_experience: number
  }>
}

export default function SearchPage() {
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [searching, setSearching] = useState(false)
  const [results, setResults] = useState<SearchResult[]>([])
  const [availableSkills, setAvailableSkills] = useState<any[]>([])
  const [skillCategories, setSkillCategories] = useState<string[]>([])

  // Search filters
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedSkill, setSelectedSkill] = useState("All Skills")
  const [selectedCategory, setSelectedCategory] = useState("All Categories")
  const [minProficiency, setMinProficiency] = useState("Any Level")
  const [minExperience, setMinExperience] = useState("Any Experience")
  const [locationFilter, setLocationFilter] = useState("")

  const router = useRouter()
  const searchParams = useSearchParams()
  const supabase = createClient()

  useEffect(() => {
    checkUser()
    loadSkills()

    // Load initial search from URL params
    const skill = searchParams.get("skill")
    const category = searchParams.get("category")
    if (skill) {
      setSelectedSkill(skill)
      performSearch(skill, category || "")
    }
  }, [])

  const checkUser = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      router.push("/auth/login")
      return
    }
    setUser(user)
    setLoading(false)
  }

  const loadSkills = async () => {
    const { data: skills } = await supabase.from("skills").select("*").order("name")

    if (skills) {
      setAvailableSkills(skills)
      const categories = [...new Set(skills.map((skill) => skill.category))].sort()
      setSkillCategories(categories)
    }
  }

  const performSearch = async (skillQuery?: string, categoryQuery?: string) => {
    setSearching(true)

    try {
      let query = supabase.from("profiles").select(`
          id,
          display_name,
          bio,
          location,
          profile_image_url,
          user_skills!inner (
            proficiency_level,
            years_experience,
            skills!inner (
              name,
              category
            )
          )
        `)

      // Apply filters
      if (skillQuery || selectedSkill !== "All Skills") {
        const skillName = skillQuery || selectedSkill
        query = query.eq("user_skills.skills.name", skillName)
      }

      if (categoryQuery || selectedCategory !== "All Categories") {
        const category = categoryQuery || selectedCategory
        query = query.eq("user_skills.skills.category", category)
      }

      if (minProficiency !== "Any Level") {
        const proficiencyOrder = { Beginner: 1, Intermediate: 2, Advanced: 3, Expert: 4 }
        const minLevel = proficiencyOrder[minProficiency as keyof typeof proficiencyOrder]
        // This would need a more complex query in a real app
      }

      if (minExperience !== "Any Experience") {
        query = query.gte("user_skills.years_experience", Number.parseInt(minExperience))
      }

      if (locationFilter) {
        query = query.ilike("location", `%${locationFilter}%`)
      }

      if (searchQuery) {
        query = query.or(`display_name.ilike.%${searchQuery}%,bio.ilike.%${searchQuery}%`)
      }

      const { data, error } = await query.limit(20)

      if (error) {
        console.error("Search error:", error)
        return
      }

      // Transform the data to match our interface
      const transformedResults: SearchResult[] =
        data?.map((profile: any) => ({
          id: profile.id,
          display_name: profile.display_name,
          bio: profile.bio,
          location: profile.location,
          profile_image_url: profile.profile_image_url,
          skills: profile.user_skills.map((us: any) => ({
            name: us.skills.name,
            category: us.skills.category,
            proficiency_level: us.proficiency_level,
            years_experience: us.years_experience,
          })),
        })) || []

      setResults(transformedResults)
    } catch (error) {
      console.error("Search error:", error)
    } finally {
      setSearching(false)
    }
  }

  const handleSearch = () => {
    performSearch()
  }

  const clearFilters = () => {
    setSearchQuery("")
    setSelectedSkill("All Skills")
    setSelectedCategory("All Categories")
    setMinProficiency("Any Level")
    setMinExperience("Any Experience")
    setLocationFilter("")
    setResults([])
  }

  const getProficiencyColor = (level: string) => {
    const normalizedLevel = level.charAt(0).toUpperCase() + level.slice(1).toLowerCase()
    switch (normalizedLevel) {
      case "Expert":
        return "bg-red-100 text-red-800"
      case "Advanced":
        return "bg-orange-100 text-orange-800"
      case "Intermediate":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/dashboard" className="text-2xl font-bold text-gray-900">
              Skill Bridge
            </Link>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {user?.email}</span>
              <Button asChild variant="outline">
                <Link href="/dashboard">Dashboard</Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Find Skill Experts</h1>
          <p className="text-gray-600">Discover talented individuals with the skills you're looking for</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Filter className="w-5 h-5" />
                  Search Filters
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* General Search */}
                <div>
                  <Label htmlFor="search">Search</Label>
                  <Input
                    id="search"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Name or bio keywords..."
                  />
                </div>

                {/* Skill Filter */}
                <div>
                  <Label htmlFor="skill">Specific Skill</Label>
                  <Select value={selectedSkill} onValueChange={setSelectedSkill}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a skill" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="All Skills">All Skills</SelectItem>
                      {availableSkills.map((skill) => (
                        <SelectItem key={skill.id} value={skill.name}>
                          {skill.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Category Filter */}
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="All Categories">All Categories</SelectItem>
                      {skillCategories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Proficiency Filter */}
                <div>
                  <Label htmlFor="proficiency">Minimum Proficiency</Label>
                  <Select value={minProficiency} onValueChange={setMinProficiency}>
                    <SelectTrigger>
                      <SelectValue placeholder="Any level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Any Level">Any Level</SelectItem>
                      <SelectItem value="Beginner">Beginner+</SelectItem>
                      <SelectItem value="Intermediate">Intermediate+</SelectItem>
                      <SelectItem value="Advanced">Advanced+</SelectItem>
                      <SelectItem value="Expert">Expert</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Experience Filter */}
                <div>
                  <Label htmlFor="experience">Minimum Experience (years)</Label>
                  <Select value={minExperience} onValueChange={setMinExperience}>
                    <SelectTrigger>
                      <SelectValue placeholder="Any experience" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Any Experience">Any Experience</SelectItem>
                      <SelectItem value="1">1+ years</SelectItem>
                      <SelectItem value="3">3+ years</SelectItem>
                      <SelectItem value="5">5+ years</SelectItem>
                      <SelectItem value="10">10+ years</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Location Filter */}
                <div>
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    value={locationFilter}
                    onChange={(e) => setLocationFilter(e.target.value)}
                    placeholder="City, Country"
                  />
                </div>

                {/* Action Buttons */}
                <div className="space-y-2 pt-4">
                  <Button onClick={handleSearch} className="w-full" disabled={searching}>
                    <Search className="w-4 h-4 mr-2" />
                    {searching ? "Searching..." : "Search"}
                  </Button>
                  <Button onClick={clearFilters} variant="outline" className="w-full bg-transparent">
                    Clear Filters
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Results */}
          <div className="lg:col-span-3">
            {results.length > 0 && (
              <div className="mb-6 flex items-center justify-between">
                <div className="flex items-center gap-2 text-gray-600">
                  <Users className="w-5 h-5" />
                  <span>{results.length} experts found</span>
                </div>
              </div>
            )}

            {searching ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p>Searching for experts...</p>
              </div>
            ) : results.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {results.map((result) => (
                  <Card key={result.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <Avatar className="w-16 h-16">
                          <AvatarImage src={result.profile_image_url || "/placeholder.svg"} />
                          <AvatarFallback className="text-lg">{result.display_name?.charAt(0) || "U"}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-lg font-semibold text-gray-900 mb-1">{result.display_name}</h3>
                          {result.location && (
                            <div className="flex items-center text-sm text-gray-600 mb-2">
                              <MapPin className="w-4 h-4 mr-1" />
                              {result.location}
                            </div>
                          )}
                          {result.bio && <p className="text-sm text-gray-600 mb-3 line-clamp-2">{result.bio}</p>}

                          {/* Skills */}
                          <div className="mb-4">
                            <div className="flex flex-wrap gap-2">
                              {result.skills.slice(0, 3).map((skill, index) => (
                                <div key={index} className="flex items-center gap-1">
                                  <Badge variant="secondary">{skill.name}</Badge>
                                  <Badge className={`text-xs ${getProficiencyColor(skill.proficiency_level)}`}>
                                    {skill.proficiency_level.charAt(0).toUpperCase() +
                                      skill.proficiency_level.slice(1).toLowerCase()}
                                  </Badge>
                                </div>
                              ))}
                              {result.skills.length > 3 && (
                                <Badge variant="outline">+{result.skills.length - 3} more</Badge>
                              )}
                            </div>
                          </div>

                          {/* Actions */}
                          <div className="flex gap-2">
                            <Button asChild size="sm" className="flex-1">
                              <Link href={`/profile/${result.id}`}>View Profile</Link>
                            </Button>
                            <Button asChild size="sm" variant="outline" className="bg-transparent">
                              <Link href={`/messages/new?user=${result.id}`}>
                                <MessageCircle className="w-4 h-4 mr-1" />
                                Message
                              </Link>
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <div className="text-gray-400 mb-4">
                    <Search className="w-12 h-12 mx-auto" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No experts found</h3>
                  <p className="text-gray-600 mb-4">
                    Try adjusting your search filters or search for different skills.
                  </p>
                  <Button onClick={() => performSearch("")} variant="outline" className="bg-transparent">
                    Browse All Experts
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
