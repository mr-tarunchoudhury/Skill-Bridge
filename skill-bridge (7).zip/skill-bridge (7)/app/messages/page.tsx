"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MessageCircle, Users, Clock, Check, X } from "lucide-react"
import Link from "next/link"

interface ConnectionRequest {
  id: string
  requester_id: string
  requested_id: string
  message: string
  status: string
  created_at: string
  requester: {
    display_name: string
    profile_image_url: string
    bio: string
  }
  requested: {
    display_name: string
    profile_image_url: string
    bio: string
  }
}

interface Conversation {
  id: string
  updated_at: string
  participants: Array<{
    user_id: string
    profiles: {
      display_name: string
      profile_image_url: string
    }
  }>
  messages: Array<{
    content: string
    created_at: string
    sender_id: string
    is_read: boolean
  }>
}

export default function MessagesPage() {
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [connectionRequests, setConnectionRequests] = useState<ConnectionRequest[]>([])
  const [sentRequests, setSentRequests] = useState<ConnectionRequest[]>([])

  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    checkUser()
  }, [])

  useEffect(() => {
    if (user) {
      loadConversations()
      loadConnectionRequests()
      setupRealtimeSubscriptions()
    }
  }, [user])

  const checkUser = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      router.push("/auth/login")
      return
    }
    setUser(user)
    setLoading(false)
  }

  const loadConversations = async () => {
    const { data, error } = await supabase
      .from("conversations")
      .select(`
        id,
        updated_at,
        conversation_participants!inner (
          user_id,
          profiles!conversation_participants_user_id_fkey (
            display_name,
            profile_image_url
          )
        ),
        messages (
          content,
          created_at,
          sender_id,
          is_read
        )
      `)
      .eq("conversation_participants.user_id", user.id)
      .order("updated_at", { ascending: false })

    if (error) {
      console.error("Error loading conversations:", error)
      return
    }

    // Transform and filter conversations
    const transformedConversations = data
      ?.map((conv: any) => ({
        id: conv.id,
        updated_at: conv.updated_at,
        participants: conv.conversation_participants.filter((p: any) => p.user_id !== user.id),
        messages: conv.messages.sort(
          (a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime(),
        ),
      }))
      .filter((conv) => conv.messages.length > 0)

    setConversations(transformedConversations || [])
  }

  const loadConnectionRequests = async () => {
    // Received requests
    const { data: received, error: receivedError } = await supabase
      .from("connection_requests")
      .select(`
        *,
        requester:profiles!connection_requests_requester_id_fkey (
          display_name,
          profile_image_url,
          bio
        )
      `)
      .eq("requested_id", user.id)
      .eq("status", "pending")
      .order("created_at", { ascending: false })

    if (receivedError) {
      console.error("Error loading received requests:", receivedError)
    } else {
      setConnectionRequests(received || [])
    }

    // Sent requests
    const { data: sent, error: sentError } = await supabase
      .from("connection_requests")
      .select(`
        *,
        requested:profiles!connection_requests_requested_id_fkey (
          display_name,
          profile_image_url,
          bio
        )
      `)
      .eq("requester_id", user.id)
      .in("status", ["pending", "accepted"])
      .order("created_at", { ascending: false })

    if (sentError) {
      console.error("Error loading sent requests:", sentError)
    } else {
      setSentRequests(sent || [])
    }
  }

  const setupRealtimeSubscriptions = () => {
    // Subscribe to new messages
    const messagesSubscription = supabase
      .channel("messages")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages" }, () => {
        loadConversations()
      })
      .subscribe()

    // Subscribe to connection requests
    const requestsSubscription = supabase
      .channel("connection_requests")
      .on("postgres_changes", { event: "*", schema: "public", table: "connection_requests" }, () => {
        loadConnectionRequests()
      })
      .subscribe()

    return () => {
      messagesSubscription.unsubscribe()
      requestsSubscription.unsubscribe()
    }
  }

  const handleConnectionRequest = async (requestId: string, action: "accept" | "reject") => {
    const { error } = await supabase
      .from("connection_requests")
      .update({ status: action === "accept" ? "accepted" : "rejected" })
      .eq("id", requestId)

    if (error) {
      console.error("Error updating connection request:", error)
      return
    }

    if (action === "accept") {
      // Create a new conversation
      const request = connectionRequests.find((r) => r.id === requestId)
      if (request) {
        const { data: conversation, error: convError } = await supabase
          .from("conversations")
          .insert({})
          .select()
          .single()

        if (!convError && conversation) {
          // Add participants
          await supabase.from("conversation_participants").insert([
            { conversation_id: conversation.id, user_id: user.id },
            { conversation_id: conversation.id, user_id: request.requester_id },
          ])

          // Send initial message
          await supabase.from("messages").insert({
            conversation_id: conversation.id,
            sender_id: user.id,
            content: "Connection accepted! Let's start chatting.",
            message_type: "text",
          })
        }
      }
    }

    loadConnectionRequests()
    loadConversations()
  }

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60)

    if (diffInHours < 24) {
      return date.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })
    } else if (diffInHours < 168) {
      return date.toLocaleDateString("en-US", { weekday: "short" })
    } else {
      return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
    }
  }

  const getUnreadCount = (conversation: Conversation) => {
    return conversation.messages.filter((msg) => !msg.is_read && msg.sender_id !== user.id).length
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/dashboard" className="text-2xl font-bold text-gray-900">
              Skill Bridge
            </Link>
            <div className="flex items-center space-x-4">
              <Button asChild variant="outline">
                <Link href="/search">Find Experts</Link>
              </Button>
              <Button asChild variant="outline">
                <Link href="/dashboard">Dashboard</Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Messages</h1>
          <p className="text-gray-600">Connect and communicate with other professionals</p>
        </div>

        <Tabs defaultValue="conversations" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="conversations" className="flex items-center gap-2">
              <MessageCircle className="w-4 h-4" />
              Conversations
              {conversations.length > 0 && <Badge variant="secondary">{conversations.length}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="requests" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Requests
              {connectionRequests.length > 0 && <Badge variant="destructive">{connectionRequests.length}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="sent" className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Sent
              {sentRequests.length > 0 && <Badge variant="secondary">{sentRequests.length}</Badge>}
            </TabsTrigger>
          </TabsList>

          {/* Conversations Tab */}
          <TabsContent value="conversations">
            {conversations.length > 0 ? (
              <div className="space-y-4">
                {conversations.map((conversation) => {
                  const otherParticipant = conversation.participants[0]
                  const lastMessage = conversation.messages[0]
                  const unreadCount = getUnreadCount(conversation)

                  return (
                    <Card key={conversation.id} className="hover:shadow-md transition-shadow cursor-pointer">
                      <Link href={`/messages/${conversation.id}`}>
                        <CardContent className="p-4">
                          <div className="flex items-center space-x-4">
                            <Avatar className="w-12 h-12">
                              <AvatarImage src={otherParticipant?.profiles?.profile_image_url || "/placeholder.svg"} />
                              <AvatarFallback>
                                {otherParticipant?.profiles?.display_name?.charAt(0) || "U"}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between">
                                <h3 className="text-lg font-semibold text-gray-900 truncate">
                                  {otherParticipant?.profiles?.display_name || "Unknown User"}
                                </h3>
                                <div className="flex items-center space-x-2">
                                  {unreadCount > 0 && (
                                    <Badge variant="destructive" className="text-xs">
                                      {unreadCount}
                                    </Badge>
                                  )}
                                  <span className="text-sm text-gray-500">
                                    {formatTime(lastMessage?.created_at || conversation.updated_at)}
                                  </span>
                                </div>
                              </div>
                              {lastMessage && (
                                <p className="text-sm text-gray-600 truncate mt-1">
                                  {lastMessage.sender_id === user.id ? "You: " : ""}
                                  {lastMessage.content}
                                </p>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Link>
                    </Card>
                  )
                })}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <MessageCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No conversations yet</h3>
                  <p className="text-gray-600 mb-4">Start connecting with other professionals to begin chatting.</p>
                  <Button asChild>
                    <Link href="/search">Find Experts</Link>
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Connection Requests Tab */}
          <TabsContent value="requests">
            {connectionRequests.length > 0 ? (
              <div className="space-y-4">
                {connectionRequests.map((request) => (
                  <Card key={request.id}>
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={request.requester.profile_image_url || "/placeholder.svg"} />
                          <AvatarFallback>{request.requester.display_name?.charAt(0) || "U"}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="text-lg font-semibold text-gray-900">{request.requester.display_name}</h3>
                            <span className="text-sm text-gray-500">{formatTime(request.created_at)}</span>
                          </div>
                          {request.requester.bio && (
                            <p className="text-sm text-gray-600 mb-3">{request.requester.bio}</p>
                          )}
                          {request.message && (
                            <div className="bg-gray-50 p-3 rounded-lg mb-4">
                              <p className="text-sm text-gray-700">"{request.message}"</p>
                            </div>
                          )}
                          <div className="flex space-x-3">
                            <Button
                              onClick={() => handleConnectionRequest(request.id, "accept")}
                              size="sm"
                              className="flex items-center gap-2"
                            >
                              <Check className="w-4 h-4" />
                              Accept
                            </Button>
                            <Button
                              onClick={() => handleConnectionRequest(request.id, "reject")}
                              variant="outline"
                              size="sm"
                              className="flex items-center gap-2 bg-transparent"
                            >
                              <X className="w-4 h-4" />
                              Decline
                            </Button>
                            <Button asChild variant="ghost" size="sm">
                              <Link href={`/profile/${request.requester_id}`}>View Profile</Link>
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No connection requests</h3>
                  <p className="text-gray-600">You don't have any pending connection requests.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Sent Requests Tab */}
          <TabsContent value="sent">
            {sentRequests.length > 0 ? (
              <div className="space-y-4">
                {sentRequests.map((request) => (
                  <Card key={request.id}>
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={request.requested.profile_image_url || "/placeholder.svg"} />
                          <AvatarFallback>{request.requested.display_name?.charAt(0) || "U"}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="text-lg font-semibold text-gray-900">{request.requested.display_name}</h3>
                            <div className="flex items-center space-x-2">
                              <Badge
                                variant={
                                  request.status === "accepted"
                                    ? "default"
                                    : request.status === "rejected"
                                      ? "destructive"
                                      : "secondary"
                                }
                              >
                                {request.status}
                              </Badge>
                              <span className="text-sm text-gray-500">{formatTime(request.created_at)}</span>
                            </div>
                          </div>
                          {request.requested.bio && (
                            <p className="text-sm text-gray-600 mb-3">{request.requested.bio}</p>
                          )}
                          {request.message && (
                            <div className="bg-gray-50 p-3 rounded-lg mb-4">
                              <p className="text-sm text-gray-700">Your message: "{request.message}"</p>
                            </div>
                          )}
                          <Button asChild variant="ghost" size="sm">
                            <Link href={`/profile/${request.requested_id}`}>View Profile</Link>
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <Clock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No sent requests</h3>
                  <p className="text-gray-600">You haven't sent any connection requests yet.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
