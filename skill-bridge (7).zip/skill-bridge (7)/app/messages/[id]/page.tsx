"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ArrowLeft, Send, Phone, Video } from "lucide-react"
import Link from "next/link"

interface Message {
  id: string
  content: string
  sender_id: string
  created_at: string
  is_read: boolean
  message_type: string
}

interface ConversationPageProps {
  params: Promise<{ id: string }>
}

export default function ConversationPage({ params }: ConversationPageProps) {
  const [conversationId, setConversationId] = useState<string>("")
  const [user, setUser] = useState<any>(null)
  const [otherUser, setOtherUser] = useState<any>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [newMessage, setNewMessage] = useState("")

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const getParams = async () => {
      const resolvedParams = await params
      setConversationId(resolvedParams.id)
    }
    getParams()
  }, [params])

  useEffect(() => {
    if (conversationId) {
      checkUser()
    }
  }, [conversationId])

  useEffect(() => {
    if (user && conversationId) {
      loadConversation()
      setupRealtimeSubscription()
    }
  }, [user, conversationId])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const checkUser = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      router.push("/auth/login")
      return
    }
    setUser(user)
    setLoading(false)
  }

  const loadConversation = async () => {
    // Load conversation details
    const { data: conversation, error } = await supabase
      .from("conversations")
      .select(`
        id,
        conversation_participants (
          user_id,
          profiles (
            id,
            display_name,
            profile_image_url
          )
        )
      `)
      .eq("id", conversationId)
      .single()

    if (error || !conversation) {
      console.error("Error loading conversation:", error)
      router.push("/messages")
      return
    }

    // Find the other user
    const otherParticipant = conversation.conversation_participants.find((p: any) => p.user_id !== user.id)
    if (otherParticipant) {
      setOtherUser(otherParticipant.profiles)
    }

    // Load messages
    const { data: messagesData, error: messagesError } = await supabase
      .from("messages")
      .select("*")
      .eq("conversation_id", conversationId)
      .order("created_at", { ascending: true })

    if (messagesError) {
      console.error("Error loading messages:", messagesError)
    } else {
      setMessages(messagesData || [])
      markMessagesAsRead()
    }
  }

  const setupRealtimeSubscription = () => {
    const subscription = supabase
      .channel(`conversation-${conversationId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `conversation_id=eq.${conversationId}`,
        },
        (payload) => {
          setMessages((prev) => [...prev, payload.new as Message])
          if (payload.new.sender_id !== user.id) {
            markMessagesAsRead()
          }
        },
      )
      .subscribe()

    return () => {
      subscription.unsubscribe()
    }
  }

  const markMessagesAsRead = async () => {
    await supabase
      .from("messages")
      .update({ is_read: true })
      .eq("conversation_id", conversationId)
      .eq("is_read", false)
      .neq("sender_id", user.id)
  }

  const sendMessage = async () => {
    if (!newMessage.trim() || sending) return

    setSending(true)

    try {
      const { error } = await supabase.from("messages").insert({
        conversation_id: conversationId,
        sender_id: user.id,
        content: newMessage.trim(),
        message_type: "text",
        is_read: false,
      })

      if (error) {
        console.error("Error sending message:", error)
        return
      }

      // Update conversation timestamp
      await supabase.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", conversationId)

      setNewMessage("")
    } catch (error) {
      console.error("Error:", error)
    } finally {
      setSending(false)
    }
  }

  const startVideoCall = () => {
    // In a real app, you'd create a call record and notify the other user
    router.push(`/call/${conversationId}`)
  }

  const startAudioCall = () => {
    // For demo purposes, redirect to video call (in real app, this would be audio-only)
    router.push(`/call/${conversationId}`)
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const today = new Date()
    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)

    if (date.toDateString() === today.toDateString()) {
      return "Today"
    } else if (date.toDateString() === yesterday.toDateString()) {
      return "Yesterday"
    } else {
      return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading conversation...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Button asChild variant="ghost" size="sm">
                <Link href="/messages" className="flex items-center gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Back
                </Link>
              </Button>
              {otherUser && (
                <div className="flex items-center space-x-3">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={otherUser.profile_image_url || "/placeholder.svg"} />
                    <AvatarFallback>{otherUser.display_name?.charAt(0) || "U"}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h1 className="text-lg font-semibold text-gray-900">{otherUser.display_name}</h1>
                  </div>
                </div>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <Button onClick={startAudioCall} variant="ghost" size="sm" className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                Audio Call
              </Button>
              <Button onClick={startVideoCall} variant="ghost" size="sm" className="flex items-center gap-2">
                <Video className="w-4 h-4" />
                Video Call
              </Button>
              {otherUser && (
                <Button asChild variant="outline" size="sm">
                  <Link href={`/profile/${otherUser.id}`}>Profile</Link>
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="h-full flex flex-col">
            <div className="flex-1 overflow-y-auto space-y-4 mb-4">
              {messages.map((message, index) => {
                const isOwnMessage = message.sender_id === user.id
                const showDate =
                  index === 0 || formatDate(message.created_at) !== formatDate(messages[index - 1].created_at)

                return (
                  <div key={message.id}>
                    {showDate && (
                      <div className="text-center text-sm text-gray-500 my-4">{formatDate(message.created_at)}</div>
                    )}
                    <div className={`flex ${isOwnMessage ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                          isOwnMessage ? "bg-blue-600 text-white" : "bg-white text-gray-900 border border-gray-200"
                        }`}
                      >
                        <p className="text-sm">{message.content}</p>
                        <p className={`text-xs mt-1 ${isOwnMessage ? "text-blue-100" : "text-gray-500"}`}>
                          {formatTime(message.created_at)}
                        </p>
                      </div>
                    </div>
                  </div>
                )
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <div className="bg-white border-t border-gray-200 p-4">
              <div className="flex space-x-4">
                <Input
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Type a message..."
                  className="flex-1"
                  disabled={sending}
                />
                <Button onClick={sendMessage} disabled={sending || !newMessage.trim()}>
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
