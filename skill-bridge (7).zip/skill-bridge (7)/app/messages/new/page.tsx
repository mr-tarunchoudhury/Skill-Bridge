"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ArrowLeft, Send } from "lucide-react"
import Link from "next/link"

export default function NewMessagePage() {
  const [user, setUser] = useState<any>(null)
  const [targetUser, setTargetUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [message, setMessage] = useState("")

  const router = useRouter()
  const searchParams = useSearchParams()
  const supabase = createClient()

  const targetUserId = searchParams.get("user")

  useEffect(() => {
    checkUser()
  }, [])

  useEffect(() => {
    if (user && targetUserId) {
      loadTargetUser()
    }
  }, [user, targetUserId])

  const checkUser = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      router.push("/auth/login")
      return
    }
    setUser(user)
    setLoading(false)
  }

  const loadTargetUser = async () => {
    if (!targetUserId) return

    const { data: profile, error } = await supabase.from("profiles").select("*").eq("id", targetUserId).single()

    if (error || !profile) {
      console.error("Error loading target user:", error)
      router.push("/search")
      return
    }

    setTargetUser(profile)
  }

  const sendConnectionRequest = async () => {
    if (!targetUserId || !message.trim()) return

    setSending(true)

    try {
      // Check if connection request already exists
      const { data: existingRequest } = await supabase
        .from("connection_requests")
        .select("*")
        .eq("requester_id", user.id)
        .eq("requested_id", targetUserId)
        .single()

      if (existingRequest) {
        alert("You've already sent a connection request to this user.")
        setSending(false)
        return
      }

      // Send connection request
      const { error } = await supabase.from("connection_requests").insert({
        requester_id: user.id,
        requested_id: targetUserId,
        message: message.trim(),
        status: "pending",
      })

      if (error) {
        console.error("Error sending connection request:", error)
        alert("Failed to send connection request. Please try again.")
        return
      }

      router.push("/messages?tab=sent")
    } catch (error) {
      console.error("Error:", error)
      alert("An error occurred. Please try again.")
    } finally {
      setSending(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading...</p>
        </div>
      </div>
    )
  }

  if (!targetUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardContent className="text-center py-12">
            <h3 className="text-lg font-medium text-gray-900 mb-2">User not found</h3>
            <p className="text-gray-600 mb-4">The user you're trying to message could not be found.</p>
            <Button asChild>
              <Link href="/search">Back to Search</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Button asChild variant="ghost" size="sm">
                <Link href="/search" className="flex items-center gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Back
                </Link>
              </Button>
              <h1 className="text-2xl font-bold text-gray-900">Send Connection Request</h1>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <Card>
          <CardHeader>
            <CardTitle>Connect with {targetUser.display_name}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Target User Info */}
            <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
              <Avatar className="w-16 h-16">
                <AvatarImage src={targetUser.profile_image_url || "/placeholder.svg"} />
                <AvatarFallback className="text-lg">{targetUser.display_name?.charAt(0) || "U"}</AvatarFallback>
              </Avatar>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{targetUser.display_name}</h3>
                {targetUser.location && <p className="text-sm text-gray-600">{targetUser.location}</p>}
                {targetUser.bio && <p className="text-sm text-gray-600 mt-1 line-clamp-2">{targetUser.bio}</p>}
              </div>
            </div>

            {/* Message Form */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="message">Connection Message *</Label>
                <Textarea
                  id="message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Hi! I'd love to connect with you. I'm interested in learning more about your expertise in..."
                  rows={4}
                  className="mt-1"
                />
                <p className="text-sm text-gray-500 mt-1">
                  Introduce yourself and explain why you'd like to connect. A personalized message increases your
                  chances of acceptance.
                </p>
              </div>

              <div className="flex space-x-4">
                <Button onClick={sendConnectionRequest} disabled={sending || !message.trim()} className="flex-1">
                  <Send className="w-4 h-4 mr-2" />
                  {sending ? "Sending..." : "Send Connection Request"}
                </Button>
                <Button asChild variant="outline" className="bg-transparent">
                  <Link href={`/profile/${targetUserId}`}>View Profile</Link>
                </Button>
              </div>
            </div>

            {/* Tips */}
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">Tips for a successful connection:</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Mention specific skills or experiences that interest you</li>
                <li>• Explain how you could mutually benefit from connecting</li>
                <li>• Keep your message concise but personal</li>
                <li>• Be respectful and professional</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
