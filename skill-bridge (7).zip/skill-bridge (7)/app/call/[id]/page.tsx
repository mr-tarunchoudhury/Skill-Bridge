"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Phone, PhoneOff, Mic, MicOff, Video, VideoOff, Monitor, MessageCircle, Settings } from "lucide-react"

interface CallPageProps {
  params: Promise<{ id: string }>
}

interface CallParticipant {
  id: string
  display_name: string
  profile_image_url: string | null
}

export default function CallPage({ params }: CallPageProps) {
  const [callId, setCallId] = useState<string>("")
  const [user, setUser] = useState<any>(null)
  const [otherUser, setOtherUser] = useState<CallParticipant | null>(null)
  const [loading, setLoading] = useState(true)
  const [callStatus, setCallStatus] = useState<"connecting" | "connected" | "ended">("connecting")
  const [isAudioEnabled, setIsAudioEnabled] = useState(true)
  const [isVideoEnabled, setIsVideoEnabled] = useState(true)
  const [isScreenSharing, setIsScreenSharing] = useState(false)
  const [callDuration, setCallDuration] = useState(0)

  // WebRTC refs
  const localVideoRef = useRef<HTMLVideoElement>(null)
  const remoteVideoRef = useRef<HTMLVideoElement>(null)
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null)
  const localStreamRef = useRef<MediaStream | null>(null)
  const callStartTimeRef = useRef<number>(0)

  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const getParams = async () => {
      const resolvedParams = await params
      setCallId(resolvedParams.id)
    }
    getParams()
  }, [params])

  useEffect(() => {
    if (callId) {
      checkUser()
    }
  }, [callId])

  useEffect(() => {
    if (user && callId) {
      initializeCall()
    }
  }, [user, callId])

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (callStatus === "connected" && callStartTimeRef.current > 0) {
      interval = setInterval(() => {
        setCallDuration(Math.floor((Date.now() - callStartTimeRef.current) / 1000))
      }, 1000)
    }
    return () => {
      if (interval) clearInterval(interval)
    }
  }, [callStatus])

  const checkUser = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      router.push("/auth/login")
      return
    }
    setUser(user)
    setLoading(false)
  }

  const initializeCall = async () => {
    try {
      // Get user media
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      })

      localStreamRef.current = stream
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream
      }

      // Initialize WebRTC
      await setupWebRTC()

      // Load other participant info (in a real app, this would come from call metadata)
      // For demo purposes, we'll simulate this
      setOtherUser({
        id: "demo-user",
        display_name: "Demo User",
        profile_image_url: null,
      })

      // Simulate connection after a delay
      setTimeout(() => {
        setCallStatus("connected")
        callStartTimeRef.current = Date.now()

        // Simulate remote video stream
        if (remoteVideoRef.current && localStreamRef.current) {
          // In a real implementation, this would be the actual remote stream
          remoteVideoRef.current.srcObject = localStreamRef.current
        }
      }, 2000)
    } catch (error) {
      console.error("Error initializing call:", error)
      alert("Failed to access camera/microphone. Please check permissions.")
      router.push("/messages")
    }
  }

  const setupWebRTC = async () => {
    const configuration = {
      iceServers: [{ urls: "stun:stun.l.google.com:19302" }, { urls: "stun:stun1.l.google.com:19302" }],
    }

    peerConnectionRef.current = new RTCPeerConnection(configuration)

    // Add local stream to peer connection
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => {
        if (peerConnectionRef.current && localStreamRef.current) {
          peerConnectionRef.current.addTrack(track, localStreamRef.current)
        }
      })
    }

    // Handle remote stream
    peerConnectionRef.current.ontrack = (event) => {
      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = event.streams[0]
      }
    }

    // Handle ICE candidates
    peerConnectionRef.current.onicecandidate = (event) => {
      if (event.candidate) {
        // In a real app, send this to the other peer via signaling server
        console.log("ICE candidate:", event.candidate)
      }
    }
  }

  const toggleAudio = () => {
    if (localStreamRef.current) {
      const audioTrack = localStreamRef.current.getAudioTracks()[0]
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled
        setIsAudioEnabled(audioTrack.enabled)
      }
    }
  }

  const toggleVideo = () => {
    if (localStreamRef.current) {
      const videoTrack = localStreamRef.current.getVideoTracks()[0]
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled
        setIsVideoEnabled(videoTrack.enabled)
      }
    }
  }

  const toggleScreenShare = async () => {
    try {
      if (!isScreenSharing) {
        // Start screen sharing
        const screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: true,
        })

        // Replace video track
        if (peerConnectionRef.current && localStreamRef.current) {
          const videoTrack = screenStream.getVideoTracks()[0]
          const sender = peerConnectionRef.current.getSenders().find((s) => s.track && s.track.kind === "video")

          if (sender) {
            await sender.replaceTrack(videoTrack)
          }

          // Update local video
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = screenStream
          }

          // Handle screen share end
          videoTrack.onended = () => {
            stopScreenShare()
          }
        }

        setIsScreenSharing(true)
      } else {
        stopScreenShare()
      }
    } catch (error) {
      console.error("Error toggling screen share:", error)
    }
  }

  const stopScreenShare = async () => {
    try {
      // Get camera stream again
      const cameraStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      })

      // Replace screen share track with camera track
      if (peerConnectionRef.current) {
        const videoTrack = cameraStream.getVideoTracks()[0]
        const sender = peerConnectionRef.current.getSenders().find((s) => s.track && s.track.kind === "video")

        if (sender) {
          await sender.replaceTrack(videoTrack)
        }

        // Update local video
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = cameraStream
        }

        localStreamRef.current = cameraStream
      }

      setIsScreenSharing(false)
    } catch (error) {
      console.error("Error stopping screen share:", error)
    }
  }

  const endCall = () => {
    // Clean up WebRTC connection
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close()
    }

    // Stop all tracks
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop())
    }

    setCallStatus("ended")

    // Redirect after a short delay
    setTimeout(() => {
      router.push("/messages")
    }, 2000)
  }

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <div className="text-center text-white">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p>Loading call...</p>
        </div>
      </div>
    )
  }

  if (callStatus === "ended") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <Card className="w-full max-w-md">
          <CardContent className="text-center py-12">
            <PhoneOff className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Call Ended</h3>
            <p className="text-gray-600 mb-4">Call duration: {formatDuration(callDuration)}</p>
            <Button onClick={() => router.push("/messages")}>Back to Messages</Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col">
      {/* Header */}
      <div className="bg-gray-800 text-white p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {otherUser && (
              <>
                <Avatar className="w-10 h-10">
                  <AvatarImage src={otherUser.profile_image_url || "/placeholder.svg"} />
                  <AvatarFallback>{otherUser.display_name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <h1 className="text-lg font-semibold">{otherUser.display_name}</h1>
                  <div className="flex items-center space-x-2">
                    <Badge
                      variant={callStatus === "connected" ? "default" : "secondary"}
                      className={callStatus === "connected" ? "bg-green-600" : ""}
                    >
                      {callStatus === "connected" ? "Connected" : "Connecting..."}
                    </Badge>
                    {callStatus === "connected" && (
                      <span className="text-sm text-gray-300">{formatDuration(callDuration)}</span>
                    )}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Video Area */}
      <div className="flex-1 relative">
        {/* Remote Video (Main) */}
        <video ref={remoteVideoRef} autoPlay playsInline className="w-full h-full object-cover" />

        {/* Local Video (Picture-in-Picture) */}
        <div className="absolute top-4 right-4 w-48 h-36 bg-gray-800 rounded-lg overflow-hidden border-2 border-gray-600">
          <video ref={localVideoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
          {!isVideoEnabled && (
            <div className="absolute inset-0 bg-gray-800 flex items-center justify-center">
              <VideoOff className="w-8 h-8 text-gray-400" />
            </div>
          )}
        </div>

        {/* Connection Status Overlay */}
        {callStatus === "connecting" && (
          <div className="absolute inset-0 bg-gray-900 bg-opacity-75 flex items-center justify-center">
            <div className="text-center text-white">
              <div className="animate-pulse mb-4">
                <Phone className="w-16 h-16 mx-auto text-blue-500" />
              </div>
              <h2 className="text-xl font-semibold mb-2">Connecting...</h2>
              <p className="text-gray-300">Please wait while we establish the connection</p>
            </div>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="bg-gray-800 p-6">
        <div className="flex items-center justify-center space-x-4">
          {/* Audio Toggle */}
          <Button
            onClick={toggleAudio}
            variant={isAudioEnabled ? "secondary" : "destructive"}
            size="lg"
            className="rounded-full w-14 h-14"
          >
            {isAudioEnabled ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
          </Button>

          {/* Video Toggle */}
          <Button
            onClick={toggleVideo}
            variant={isVideoEnabled ? "secondary" : "destructive"}
            size="lg"
            className="rounded-full w-14 h-14"
          >
            {isVideoEnabled ? <Video className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
          </Button>

          {/* Screen Share */}
          <Button
            onClick={toggleScreenShare}
            variant={isScreenSharing ? "default" : "secondary"}
            size="lg"
            className="rounded-full w-14 h-14"
          >
            <Monitor className="w-6 h-6" />
          </Button>

          {/* End Call */}
          <Button
            onClick={endCall}
            variant="destructive"
            size="lg"
            className="rounded-full w-14 h-14 bg-red-600 hover:bg-red-700"
          >
            <PhoneOff className="w-6 h-6" />
          </Button>

          {/* Chat */}
          <Button
            onClick={() => router.push(`/messages/${callId}`)}
            variant="secondary"
            size="lg"
            className="rounded-full w-14 h-14"
          >
            <MessageCircle className="w-6 h-6" />
          </Button>

          {/* Settings */}
          <Button variant="secondary" size="lg" className="rounded-full w-14 h-14">
            <Settings className="w-6 h-6" />
          </Button>
        </div>

        {/* Status Indicators */}
        <div className="flex items-center justify-center space-x-6 mt-4 text-sm text-gray-400">
          <div className="flex items-center space-x-1">
            {isAudioEnabled ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
            <span>{isAudioEnabled ? "Audio On" : "Audio Off"}</span>
          </div>
          <div className="flex items-center space-x-1">
            {isVideoEnabled ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
            <span>{isVideoEnabled ? "Video On" : "Video Off"}</span>
          </div>
          {isScreenSharing && (
            <div className="flex items-center space-x-1">
              <Monitor className="w-4 h-4" />
              <span>Screen Sharing</span>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
