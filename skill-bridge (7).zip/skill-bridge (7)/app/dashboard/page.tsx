import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default async function DashboardPage() {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", data.user.id).single()

  const handleSignOut = async () => {
    "use server"
    const supabase = await createClient()
    await supabase.auth.signOut()
    redirect("/auth/login")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-900">Skill Bridge</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {profile?.display_name || data.user.email}</span>
              <form action={handleSignOut}>
                <Button variant="outline" type="submit">
                  Sign Out
                </Button>
              </form>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Welcome to Skill Bridge!</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Your account has been successfully created. Let's get started by setting up your profile.
              </p>
              <Button asChild className="w-full">
                <Link href="/profile/setup">Complete Profile Setup</Link>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Find Skills</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Search for people with specific skills and connect with experts in your field.
              </p>
              <Button asChild variant="outline" className="w-full bg-transparent">
                <Link href="/search">Search Skills</Link>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Messages</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Connect with other users and start meaningful conversations.</p>
              <Button asChild variant="outline" className="w-full bg-transparent">
                <Link href="/messages">View Messages</Link>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Your Profile</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">View and manage your professional profile and skills.</p>
              <Button asChild variant="outline" className="w-full bg-transparent">
                <Link href={`/profile/${data.user.id}`}>View Profile</Link>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Popular Skills</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Explore trending skills and find experts in high-demand areas.</p>
              <div className="space-y-2">
                <Button asChild variant="outline" size="sm" className="w-full bg-transparent">
                  <Link href="/search?skill=JavaScript">JavaScript Experts</Link>
                </Button>
                <Button asChild variant="outline" size="sm" className="w-full bg-transparent">
                  <Link href="/search?skill=Python">Python Developers</Link>
                </Button>
                <Button asChild variant="outline" size="sm" className="w-full bg-transparent">
                  <Link href="/search?category=Design">Design Professionals</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Community Feed</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Share knowledge, announce meetings, and connect with the community.</p>
              <Button asChild variant="outline" className="w-full bg-transparent">
                <Link href="/feed">Explore Feed</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
