"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, X, MapPin, Briefcase, GraduationCap } from "lucide-react"

interface Skill {
  id: string
  name: string
  category: string
}

interface UserSkill {
  skill_id: string
  skill_name: string
  proficiency_level: string
  years_experience: number
}

interface Education {
  institution: string
  degree: string
  field_of_study: string
  start_date: string
  end_date: string
  description: string
}

interface Experience {
  company: string
  position: string
  start_date: string
  end_date: string
  is_current: boolean
  description: string
}

export default function ProfileSetupPage() {
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  // Profile data
  const [displayName, setDisplayName] = useState("")
  const [bio, setBio] = useState("")
  const [location, setLocation] = useState("")
  const [websiteUrl, setWebsiteUrl] = useState("")
  const [linkedinUrl, setLinkedinUrl] = useState("")
  const [githubUrl, setGithubUrl] = useState("")

  // Skills data
  const [availableSkills, setAvailableSkills] = useState<Skill[]>([])
  const [selectedSkills, setSelectedSkills] = useState<UserSkill[]>([])
  const [newSkillName, setNewSkillName] = useState("")
  const [newSkillCategory, setNewSkillCategory] = useState("")

  // Education data
  const [education, setEducation] = useState<Education[]>([])

  // Experience data
  const [experience, setExperience] = useState<Experience[]>([])

  useEffect(() => {
    checkUser()
    loadSkills()
  }, [])

  const checkUser = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      router.push("/auth/login")
      return
    }
    setUser(user)

    // Check if profile already exists
    try {
      const { data: profile, error } = await supabase.from("profiles").select("*").eq("id", user.id).single()

      if (profile && !error) {
        setDisplayName(profile.display_name || "")
        setBio(profile.bio || "")
        setLocation(profile.location || "")
        setWebsiteUrl(profile.website_url || "")
        setLinkedinUrl(profile.linkedin_url || "")
        setGithubUrl(profile.github_url || "")
      }
    } catch (error) {
      console.error("Error loading profile:", error)
    }

    setLoading(false)
  }

  const loadSkills = async () => {
    const { data: skills } = await supabase.from("skills").select("*").order("name")

    if (skills) {
      setAvailableSkills(skills)
    }
  }

  const addSkill = async () => {
    if (!newSkillName.trim()) return

    // Check if skill exists
    let skill = availableSkills.find((s) => s.name.toLowerCase() === newSkillName.toLowerCase())

    if (!skill) {
      // Create new skill
      const { data: newSkill, error } = await supabase
        .from("skills")
        .insert({
          name: newSkillName,
          category: newSkillCategory || "Other",
        })
        .select()
        .single()

      if (error) {
        console.error("Error creating skill:", error)
        return
      }

      skill = newSkill
      setAvailableSkills([...availableSkills, skill])
    }

    // Add to selected skills
    if (!selectedSkills.find((s) => s.skill_id === skill.id)) {
      setSelectedSkills([
        ...selectedSkills,
        {
          skill_id: skill.id,
          skill_name: skill.name,
          proficiency_level: "Beginner",
          years_experience: 1,
        },
      ])
    }

    setNewSkillName("")
    setNewSkillCategory("")
  }

  const removeSkill = (skillId: string) => {
    setSelectedSkills(selectedSkills.filter((s) => s.skill_id !== skillId))
  }

  const updateSkill = (skillId: string, field: string, value: any) => {
    setSelectedSkills(selectedSkills.map((s) => (s.skill_id === skillId ? { ...s, [field]: value } : s)))
  }

  const addEducation = () => {
    setEducation([
      ...education,
      {
        institution: "",
        degree: "",
        field_of_study: "",
        start_date: "",
        end_date: "",
        description: "",
      },
    ])
  }

  const removeEducation = (index: number) => {
    setEducation(education.filter((_, i) => i !== index))
  }

  const updateEducation = (index: number, field: string, value: string) => {
    setEducation(education.map((edu, i) => (i === index ? { ...edu, [field]: value } : edu)))
  }

  const addExperience = () => {
    setExperience([
      ...experience,
      {
        company: "",
        position: "",
        start_date: "",
        end_date: "",
        is_current: false,
        description: "",
      },
    ])
  }

  const removeExperience = (index: number) => {
    setExperience(experience.filter((_, i) => i !== index))
  }

  const updateExperience = (index: number, field: string, value: any) => {
    setExperience(experience.map((exp, i) => (i === index ? { ...exp, [field]: value } : exp)))
  }

  const saveProfile = async () => {
    if (!user) return
    setSaving(true)

    try {
      console.log("[v0] Starting profile save process")
      console.log("[v0] Selected skills:", selectedSkills)

      // Save profile
      const { error: profileError } = await supabase.from("profiles").upsert({
        id: user.id,
        display_name: displayName,
        bio: bio,
        location: location,
        website_url: websiteUrl || null,
        linkedin_url: linkedinUrl || null,
        github_url: githubUrl || null,
      })

      if (profileError) throw profileError

      // Save skills
      if (selectedSkills.length > 0) {
        // Delete existing skills
        await supabase.from("user_skills").delete().eq("user_id", user.id)

        const skillsToInsert = selectedSkills.map((skill) => ({
          user_id: user.id,
          skill_id: skill.skill_id,
          proficiency_level: skill.proficiency_level.toLowerCase(),
          years_experience: skill.years_experience,
        }))

        console.log("[v0] Skills to insert:", skillsToInsert)

        // Insert new skills
        const { error: skillsError } = await supabase.from("user_skills").insert(skillsToInsert)

        if (skillsError) {
          console.error("[v0] Skills insert error:", skillsError)
          throw skillsError
        }
      }

      // Save education
      if (education.length > 0) {
        await supabase.from("education").delete().eq("user_id", user.id)

        const { error: educationError } = await supabase.from("education").insert(
          education.map((edu) => ({
            user_id: user.id,
            ...edu,
          })),
        )

        if (educationError) throw educationError
      }

      // Save experience
      if (experience.length > 0) {
        await supabase.from("experience").delete().eq("user_id", user.id)

        const { error: experienceError } = await supabase.from("experience").insert(
          experience.map((exp) => ({
            user_id: user.id,
            ...exp,
          })),
        )

        if (experienceError) throw experienceError
      }

      router.push("/dashboard")
    } catch (error) {
      console.error("Error saving profile:", error)
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Complete Your Profile</h1>
          <p className="text-gray-600">Help others discover your skills and expertise</p>
        </div>

        <div className="space-y-8">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Basic Information
              </CardTitle>
              <CardDescription>Tell us about yourself</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="displayName">Display Name *</Label>
                  <Input
                    id="displayName"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="Your display name"
                  />
                </div>
                <div>
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="City, Country"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                  id="bio"
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="Tell us about yourself, your interests, and what you're passionate about..."
                  rows={4}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="website">Website</Label>
                  <Input
                    id="website"
                    value={websiteUrl}
                    onChange={(e) => setWebsiteUrl(e.target.value)}
                    placeholder="https://yourwebsite.com"
                  />
                </div>
                <div>
                  <Label htmlFor="linkedin">LinkedIn</Label>
                  <Input
                    id="linkedin"
                    value={linkedinUrl}
                    onChange={(e) => setLinkedinUrl(e.target.value)}
                    placeholder="https://linkedin.com/in/username"
                  />
                </div>
                <div>
                  <Label htmlFor="github">GitHub</Label>
                  <Input
                    id="github"
                    value={githubUrl}
                    onChange={(e) => setGithubUrl(e.target.value)}
                    placeholder="https://github.com/username"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Skills */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="w-5 h-5" />
                Skills & Expertise
              </CardTitle>
              <CardDescription>Add your skills and expertise levels</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  value={newSkillName}
                  onChange={(e) => setNewSkillName(e.target.value)}
                  placeholder="Add a skill..."
                  className="flex-1"
                />
                <Select value={newSkillCategory} onValueChange={setNewSkillCategory}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Programming">Programming</SelectItem>
                    <SelectItem value="Design">Design</SelectItem>
                    <SelectItem value="Marketing">Marketing</SelectItem>
                    <SelectItem value="Business">Business</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={addSkill}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>

              <div className="space-y-3">
                {selectedSkills.map((skill) => (
                  <div key={skill.skill_id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <Badge variant="secondary">{skill.skill_name}</Badge>
                    <Select
                      value={skill.proficiency_level}
                      onValueChange={(value) => updateSkill(skill.skill_id, "proficiency_level", value)}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Beginner">Beginner</SelectItem>
                        <SelectItem value="Intermediate">Intermediate</SelectItem>
                        <SelectItem value="Advanced">Advanced</SelectItem>
                        <SelectItem value="Expert">Expert</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      type="number"
                      min="0"
                      max="50"
                      value={skill.years_experience}
                      onChange={(e) =>
                        updateSkill(skill.skill_id, "years_experience", Number.parseInt(e.target.value) || 0)
                      }
                      className="w-20"
                      placeholder="Years"
                    />
                    <Button variant="ghost" size="sm" onClick={() => removeSkill(skill.skill_id)}>
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Education */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5" />
                Education
              </CardTitle>
              <CardDescription>Add your educational background</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button onClick={addEducation} variant="outline" className="w-full bg-transparent">
                <Plus className="w-4 h-4 mr-2" />
                Add Education
              </Button>

              {education.map((edu, index) => (
                <div key={index} className="p-4 border rounded-lg space-y-3">
                  <div className="flex justify-between items-start">
                    <h4 className="font-medium">Education {index + 1}</h4>
                    <Button variant="ghost" size="sm" onClick={() => removeEducation(index)}>
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <Input
                      value={edu.institution}
                      onChange={(e) => updateEducation(index, "institution", e.target.value)}
                      placeholder="Institution"
                    />
                    <Input
                      value={edu.degree}
                      onChange={(e) => updateEducation(index, "degree", e.target.value)}
                      placeholder="Degree"
                    />
                    <Input
                      value={edu.field_of_study}
                      onChange={(e) => updateEducation(index, "field_of_study", e.target.value)}
                      placeholder="Field of Study"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        type="date"
                        value={edu.start_date}
                        onChange={(e) => updateEducation(index, "start_date", e.target.value)}
                      />
                      <Input
                        type="date"
                        value={edu.end_date}
                        onChange={(e) => updateEducation(index, "end_date", e.target.value)}
                      />
                    </div>
                  </div>
                  <Textarea
                    value={edu.description}
                    onChange={(e) => updateEducation(index, "description", e.target.value)}
                    placeholder="Description (optional)"
                    rows={2}
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Experience */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="w-5 h-5" />
                Work Experience
              </CardTitle>
              <CardDescription>Add your professional experience</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button onClick={addExperience} variant="outline" className="w-full bg-transparent">
                <Plus className="w-4 h-4 mr-2" />
                Add Experience
              </Button>

              {experience.map((exp, index) => (
                <div key={index} className="p-4 border rounded-lg space-y-3">
                  <div className="flex justify-between items-start">
                    <h4 className="font-medium">Experience {index + 1}</h4>
                    <Button variant="ghost" size="sm" onClick={() => removeExperience(index)}>
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <Input
                      value={exp.company}
                      onChange={(e) => updateExperience(index, "company", e.target.value)}
                      placeholder="Company"
                    />
                    <Input
                      value={exp.position}
                      onChange={(e) => updateExperience(index, "position", e.target.value)}
                      placeholder="Position"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        type="date"
                        value={exp.start_date}
                        onChange={(e) => updateExperience(index, "start_date", e.target.value)}
                      />
                      <Input
                        type="date"
                        value={exp.end_date}
                        onChange={(e) => updateExperience(index, "end_date", e.target.value)}
                        disabled={exp.is_current}
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`current-${index}`}
                        checked={exp.is_current}
                        onChange={(e) => updateExperience(index, "is_current", e.target.checked)}
                        className="rounded"
                      />
                      <Label htmlFor={`current-${index}`}>Currently working here</Label>
                    </div>
                  </div>
                  <Textarea
                    value={exp.description}
                    onChange={(e) => updateExperience(index, "description", e.target.value)}
                    placeholder="Description of your role and achievements"
                    rows={3}
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Save Button */}
          <div className="flex justify-center">
            <Button onClick={saveProfile} disabled={saving || !displayName.trim()} size="lg" className="px-8">
              {saving ? "Saving..." : "Save Profile"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
