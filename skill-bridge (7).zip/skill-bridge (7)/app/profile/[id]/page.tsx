import { notFound, redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MapPin, Globe, Linkedin, Github, MessageCircle, Calendar, Building, GraduationCap } from "lucide-react"
import Link from "next/link"

interface ProfilePageProps {
  params: Promise<{ id: string }>
}

export default async function ProfilePage({ params }: ProfilePageProps) {
  const { id } = await params

  if (id === "setup") {
    redirect("/profile/setup")
  }

  const supabase = await createClient()

  // Get current user
  const {
    data: { user: currentUser },
  } = await supabase.auth.getUser()
  if (!currentUser) {
    redirect("/auth/login")
  }

  const { data: profile, error } = await supabase.from("profiles").select("*").eq("id", id).single()

  if (error) {
    console.error("Profile lookup error:", error)
    notFound()
  }

  if (!profile) {
    notFound()
  }

  // Get user skills
  const { data: userSkills } = await supabase
    .from("user_skills")
    .select(`
      *,
      skills:skill_id (
        name,
        category
      )
    `)
    .eq("user_id", id)

  // Get education
  const { data: education } = await supabase
    .from("education")
    .select("*")
    .eq("user_id", id)
    .order("start_date", { ascending: false })

  // Get experience
  const { data: experience } = await supabase
    .from("experience")
    .select("*")
    .eq("user_id", id)
    .order("start_date", { ascending: false })

  const isOwnProfile = currentUser.id === id

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/dashboard" className="text-2xl font-bold text-gray-900">
              Skill Bridge
            </Link>
            <div className="flex items-center space-x-4">
              {isOwnProfile ? (
                <Button asChild>
                  <Link href="/profile/setup">Edit Profile</Link>
                </Button>
              ) : (
                <Button asChild>
                  <Link href={`/messages/new?user=${id}`}>
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Send Message
                  </Link>
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Profile Info */}
          <div className="lg:col-span-1 space-y-6">
            {/* Profile Card */}
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <Avatar className="w-24 h-24 mx-auto mb-4">
                    <AvatarImage src={profile.profile_image_url || "/placeholder.svg"} />
                    <AvatarFallback className="text-2xl">{profile.display_name?.charAt(0) || "U"}</AvatarFallback>
                  </Avatar>
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">{profile.display_name}</h1>
                  {profile.location && (
                    <div className="flex items-center justify-center text-gray-600 mb-4">
                      <MapPin className="w-4 h-4 mr-1" />
                      {profile.location}
                    </div>
                  )}
                  {profile.bio && <p className="text-gray-600 text-sm leading-relaxed">{profile.bio}</p>}
                </div>

                {/* Social Links */}
                <div className="mt-6 flex justify-center space-x-4">
                  {profile.website_url && (
                    <a
                      href={profile.website_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-600 hover:text-blue-600 transition-colors"
                    >
                      <Globe className="w-5 h-5" />
                    </a>
                  )}
                  {profile.linkedin_url && (
                    <a
                      href={profile.linkedin_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-600 hover:text-blue-600 transition-colors"
                    >
                      <Linkedin className="w-5 h-5" />
                    </a>
                  )}
                  {profile.github_url && (
                    <a
                      href={profile.github_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-600 hover:text-blue-600 transition-colors"
                    >
                      <Github className="w-5 h-5" />
                    </a>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Skills Card */}
            {userSkills && userSkills.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Skills & Expertise</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {userSkills.map((userSkill: any) => (
                      <div key={userSkill.id} className="flex items-center justify-between">
                        <div>
                          <Badge variant="secondary" className="mb-1">
                            {userSkill.skills.name}
                          </Badge>
                          <div className="text-xs text-gray-600">
                            {userSkill.proficiency_level.charAt(0).toUpperCase() +
                              userSkill.proficiency_level.slice(1).toLowerCase()}{" "}
                            • {userSkill.years_experience} years
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Column - Experience & Education */}
          <div className="lg:col-span-2 space-y-6">
            {/* Experience */}
            {experience && experience.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building className="w-5 h-5" />
                    Work Experience
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {experience.map((exp: any) => (
                      <div key={exp.id} className="border-l-2 border-blue-200 pl-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-semibold text-gray-900">{exp.position}</h3>
                            <p className="text-blue-600 font-medium">{exp.company}</p>
                            <div className="flex items-center text-sm text-gray-600 mt-1">
                              <Calendar className="w-4 h-4 mr-1" />
                              {new Date(exp.start_date).toLocaleDateString("en-US", {
                                month: "short",
                                year: "numeric",
                              })}{" "}
                              -{" "}
                              {exp.is_current
                                ? "Present"
                                : new Date(exp.end_date).toLocaleDateString("en-US", {
                                    month: "short",
                                    year: "numeric",
                                  })}
                            </div>
                          </div>
                        </div>
                        {exp.description && (
                          <p className="text-gray-600 text-sm mt-2 leading-relaxed">{exp.description}</p>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Education */}
            {education && education.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <GraduationCap className="w-5 h-5" />
                    Education
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {education.map((edu: any) => (
                      <div key={edu.id} className="border-l-2 border-green-200 pl-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-semibold text-gray-900">{edu.degree}</h3>
                            <p className="text-green-600 font-medium">{edu.institution}</p>
                            {edu.field_of_study && <p className="text-gray-600 text-sm">{edu.field_of_study}</p>}
                            <div className="flex items-center text-sm text-gray-600 mt-1">
                              <Calendar className="w-4 h-4 mr-1" />
                              {new Date(edu.start_date).toLocaleDateString("en-US", {
                                month: "short",
                                year: "numeric",
                              })}{" "}
                              -{" "}
                              {new Date(edu.end_date).toLocaleDateString("en-US", {
                                month: "short",
                                year: "numeric",
                              })}
                            </div>
                          </div>
                        </div>
                        {edu.description && (
                          <p className="text-gray-600 text-sm mt-2 leading-relaxed">{edu.description}</p>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Empty State */}
            {(!experience || experience.length === 0) && (!education || education.length === 0) && (
              <Card>
                <CardContent className="text-center py-12">
                  <div className="text-gray-400 mb-4">
                    <Building className="w-12 h-12 mx-auto" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No experience or education added yet</h3>
                  <p className="text-gray-600">
                    {isOwnProfile
                      ? "Add your professional background to help others understand your expertise."
                      : "This user hasn't added their professional background yet."}
                  </p>
                  {isOwnProfile && (
                    <Button asChild className="mt-4">
                      <Link href="/profile/setup">Complete Profile</Link>
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
