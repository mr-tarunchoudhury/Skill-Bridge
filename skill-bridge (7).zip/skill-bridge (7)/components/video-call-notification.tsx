"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Phone, PhoneOff, Video } from "lucide-react"

interface VideoCallNotificationProps {
  isVisible: boolean
  callerName: string
  callerImage?: string
  onAccept: () => void
  onDecline: () => void
  isVideoCall?: boolean
}

export default function VideoCallNotification({
  isVisible,
  callerName,
  callerImage,
  onAccept,
  onDecline,
  isVideoCall = true,
}: VideoCallNotificationProps) {
  const [isRinging, setIsRinging] = useState(false)

  useEffect(() => {
    if (isVisible) {
      setIsRinging(true)
      // Auto-decline after 30 seconds
      const timeout = setTimeout(() => {
        onDecline()
      }, 30000)

      return () => clearTimeout(timeout)
    } else {
      setIsRinging(false)
    }
  }, [isVisible, onDecline])

  if (!isVisible) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
      <Card className="w-full max-w-sm mx-4">
        <CardContent className="text-center py-8">
          <div className={`mb-6 ${isRinging ? "animate-pulse" : ""}`}>
            <Avatar className="w-24 h-24 mx-auto mb-4">
              <AvatarImage src={callerImage || "/placeholder.svg"} />
              <AvatarFallback className="text-2xl">{callerName.charAt(0)}</AvatarFallback>
            </Avatar>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">{callerName}</h2>
            <p className="text-gray-600">Incoming {isVideoCall ? "video" : "audio"} call...</p>
          </div>

          <div className="flex justify-center space-x-8">
            <Button
              onClick={onDecline}
              variant="destructive"
              size="lg"
              className="rounded-full w-16 h-16 bg-red-600 hover:bg-red-700"
            >
              <PhoneOff className="w-6 h-6" />
            </Button>
            <Button onClick={onAccept} size="lg" className="rounded-full w-16 h-16 bg-green-600 hover:bg-green-700">
              {isVideoCall ? <Video className="w-6 h-6" /> : <Phone className="w-6 h-6" />}
            </Button>
          </div>

          <div className="mt-4 text-sm text-gray-500">{isVideoCall ? "Video call" : "Audio call"}</div>
        </CardContent>
      </Card>
    </div>
  )
}
