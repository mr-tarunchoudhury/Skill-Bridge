-- Check the constraint definition for user_skills table
SELECT 
    tc.constraint_name, 
    tc.constraint_type,
    cc.check_clause
FROM information_schema.table_constraints tc
JOIN information_schema.check_constraints cc 
    ON tc.constraint_name = cc.constraint_name
WHERE tc.table_name = 'user_skills' 
    AND tc.constraint_type = 'CHECK';

-- Also check what values currently exist in the database
SELECT DISTINCT proficiency_level 
FROM user_skills 
WHERE proficiency_level IS NOT NULL;
